import adsk.core, adsk.fusion, traceback, math

def run(context):
    ui = None
    try: 
        app = adsk.core.Application.get()
        ui = app.userInterface

        doc = app.documents.add(adsk.core.DocumentTypes.FusionDesignDocumentType)
        design = app.activeProduct
        rootComp = design.rootComponent

        sketch = rootComp.sketches.add(rootComp.xYConstructionPlane)
        points = adsk.core.ObjectCollection.create()
        pointsGroove = adsk.core.ObjectCollection.create()
        lines = sketch.sketchCurves.sketchLines
        features = rootComp.features
        extrudes = features.extrudeFeatures
        circlesPatterns = features.circularPatternFeatures
        # chamfer = root.features.chamferFeatures 

        # Define the points the spline with fit through.
        points.add(adsk.core.Point3D.create(5.5, 30, 0))
        points.add(adsk.core.Point3D.create(14, 30, 0))
        points.add(adsk.core.Point3D.create(14, 8, 0))
        points.add(adsk.core.Point3D.create(40, 8, 0))
        points.add(adsk.core.Point3D.create(40, 0, 0))
        points.add(adsk.core.Point3D.create(12.5, 0, 0))
        points.add(adsk.core.Point3D.create(12.5, 2, 0))
        points.add(adsk.core.Point3D.create(5.5, 2, 0))
        points.add(adsk.core.Point3D.create(5.5, 40, 0))

        for i in range(points.count-1):
            pt1 = points.item(i)
            pt2 = points.item(i+1)
            sketch.sketchCurves.sketchLines.addByTwoPoints(pt1, pt2)
        
        centerLine = lines.addByTwoPoints(adsk.core.Point3D.create(0, 0, 0), adsk.core.Point3D.create(0, 100, 0))
        profRevolvle = sketch.profiles.item(0)
        revolves = rootComp.features.revolveFeatures
        revInput = revolves.createInput(profRevolvle, centerLine, adsk.fusion.FeatureOperations.NewComponentFeatureOperation)
        angle = adsk.core.ValueInput.createByReal(math.pi*2)
        revInput.setAngleExtent(False, angle)
        ext = revolves.add(revInput)

        sketchGroove = rootComp.sketches.add(rootComp.xZConstructionPlane)
        pointsGroove.add(adsk.core.Point3D.create(4.61, 3, 30))
        pointsGroove.add(adsk.core.Point3D.create(6.61, 3, 30))
        pointsGroove.add(adsk.core.Point3D.create(6.61, -3, 30))
        pointsGroove.add(adsk.core.Point3D.create(4.61, -3, 30))
        pointsGroove.add(adsk.core.Point3D.create(4.61, 3, 30))

        for i in range(pointsGroove.count-1):
            ptGroove1 = pointsGroove.item(i)
            ptGroove2 = pointsGroove.item(i+1)
            sketchGroove.sketchCurves.sketchLines.addByTwoPoints(ptGroove1, ptGroove2)
            
        extGroove = adsk.core.ObjectCollection.create()
        extGroove = sketchGroove.profiles.item(0)
        extrudeFeatureGroove = features.extrudeFeatures 
        extrudeFeatureInputGroove = extrudes.createInput(extGroove, adsk.fusion.FeatureOperations.CutFeatureOperation)
        extrudeFeatureInputGroove.isSolid = True
        extrudeFeatureInputGroove.setDistanceExtent(True, adsk.core.ValueInput.createByReal(500))
        extGrooveInput = extrudes.add(extrudeFeatureInputGroove)

        # holes = extHoles.bodies.item(0)
        # yAxis = rootComp.yConstructionAxis
        # circularFeatInput = circlesPatterns.createInput(holes, yAxis)
        # holesQuantity = adsk.core.ValueInput.createByReal(4)
        # circularFeatInput.quantity = holesQuantity
        # circularFeatInput.totalAngle = adsk.core.ValueInput.createByString('360 deg')
        # circularFeatInput.isSymmetric = True
        # patterns = circlesPatterns.add(circularFeatInput)

        sketchSec = rootComp.sketches.add(rootComp.xZConstructionPlane)
        sketchCircles = sketchSec.sketchCurves.sketchCircles
        centerPoint = adsk.core.Point3D.create(27.5, 0, 0) 
        sketchCircles.addByCenterRadius(centerPoint, 4.2)

        extAll = adsk.core.ObjectCollection.create()
        extAll.add(sketchSec.profiles.item(0))
        extrudeFeature = features.extrudeFeatures 
        extrudeFeatureInput = extrudeFeature.createInput(extAll, adsk.fusion.FeatureOperations.CutFeatureOperation)
        extrudeFeatureInput.isSolid = True
        extrudeFeatureInput.setDistanceExtent(False, adsk.core.ValueInput.createByReal(10))
        hole = extrudeFeature.add(extrudeFeatureInput)

        patternsBody = hole.bodies.item(0)
        patternsFace = patternsBody.faces.item(0)

        inputEntites = adsk.core.ObjectCollection.create()
        inputEntites.add(patternsFace)

        yAxis = rootComp.yConstructionAxis

        circularFeats = rootComp.features.circularPatternFeatures
        circularFeatInput = circularFeats.createInput(inputEntites, yAxis)
        circularFeatInput.quantity = adsk.core.ValueInput.createByReal(4)
        circularFeatInput.totalAngle = adsk.core.ValueInput.createByString('360 deg')
        circularFeatInput.isSymmetric = False
        circularFeat = circularFeats.add(circularFeatInput)
     
    except:
        if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))

